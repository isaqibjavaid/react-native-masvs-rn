import * as Keychain from 'react-native-keychain';
export type StoragePolicy = {
    requireAuth?: boolean;
    service?: string;
    accessible?: Keychain.ACCESSIBLE;
    authenticationType?: Keychain.AUTHENTICATION_TYPE;
};
export declare const secureStorage: {
    setSecret(key: string, value: string, policy?: StoragePolicy): Promise<false | Keychain.Result>;
    getSecret(key: string, policy?: StoragePolicy): Promise<string | null>;
    deleteSecret(policy?: StoragePolicy): Promise<boolean>;
    wipeAll(policy?: StoragePolicy): Promise<boolean>;
};
//# sourceMappingURL=index.d.ts.map