export declare const secureStorage: {
    setSecret(key: string, value: string, options?: any): any;
    getSecret(key: string): any;
    deleteSecret(key: string): any;
};
//# sourceMappingURL=index.d.ts.map