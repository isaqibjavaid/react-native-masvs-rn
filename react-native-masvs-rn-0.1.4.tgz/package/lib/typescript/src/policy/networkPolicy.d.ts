export type PinningMode = 'none' | 'publicKey' | 'certificate';
export type HostPolicy = {
    mode?: PinningMode;
    pins?: string[];
    failClosed?: boolean;
    timeoutMs?: number;
};
export type NetworkPolicy = {
    default: HostPolicy;
    hosts: Record<string, HostPolicy>;
};
export declare const networkPolicy: NetworkPolicy;
//# sourceMappingURL=networkPolicy.d.ts.map