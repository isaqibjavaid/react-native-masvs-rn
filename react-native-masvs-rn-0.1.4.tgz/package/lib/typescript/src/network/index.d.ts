/**
 * Keep our public API simple and compatible with secure JSON requests.
 * IMPORTANT: react-native-ssl-pinning Options expects body: string | object | undefined
 * so we do not accept FormData/Blob/null here.
 */
export type SecureFetchOptions = {
    method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
    headers?: Record<string, string>;
    body?: string | object;
    timeoutMs?: number;
};
export declare function secureFetch(url: string, opts?: SecureFetchOptions): Promise<Response | import("react-native-ssl-pinning").ReactNativeSSLPinning.Response>;
//# sourceMappingURL=index.d.ts.map